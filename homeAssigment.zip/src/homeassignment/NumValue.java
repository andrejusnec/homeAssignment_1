/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package homeassignment;

/**
 *
 * @author kilgo
 */
public class NumValue {

    String key;
    Object value;

    public NumValue(String key, Object value) {
        this.key = key;
        this.value = value;
    }
}
