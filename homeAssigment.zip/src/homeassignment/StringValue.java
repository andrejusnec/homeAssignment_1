package homeassignment;

public class StringValue {

    String key;
    String value;

    public StringValue(String key, String value) {
        this.key = key;
        this.value = value;
    }
}
