********************************Home Assigment by Andrejus Necvetnas**********************************
**********************************email:andrejus.necvetnas@gmail.com**********************************
In this project im using libraries:
Json simple library 1.1.1v
Apache HttpClient 4.5v

